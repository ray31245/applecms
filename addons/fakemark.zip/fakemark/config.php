<?php

return array (
  0 => 
  array (
    'name' => 'strict_mode',
    'title' => '控制模式1',
    'type' => 'radio',
    'content' => 
    array (
      1 => '开启',
      0 => '关闭',
    ),
    'value' => '0',
    'rule' => '',
    'msg' => '',
    'tip' => '开启后只有移动端百度蜘蛛和百度搜索来路的客户可以访问真实页面，其他访问者将返回503状态码',
    'ok' => '',
    'extend' => '',
  ),
  1 => 
  array (
    'name' => 'strict_mode2',
    'title' => '控制模式2',
    'type' => 'radio',
    'content' => 
    array (
      1 => '开启',
      0 => '关闭',
    ),
    'value' => '0',
    'rule' => '',
    'msg' => '',
    'tip' => '开启后只有移动端百度蜘蛛可以显示真实页面，百度搜索来路的客户访问则跳转广告链接，其他访问者将返回503状态码',
    'ok' => '',
    'extend' => '',
  ),
  2 => 
  array (
    'name' => 'strict_mode3',
    'title' => '控制模式3',
    'type' => 'radio',
    'content' => 
    array (
      1 => '开启',
      0 => '关闭',
    ),
    'value' => '0',
    'rule' => '',
    'msg' => '',
    'tip' => '开启后只有移动端百度蜘蛛可以显示真实页面，百度来路的PC端返回503状态码，百度来路的手机端访问则跳转广告链接',
    'ok' => '',
    'extend' => '',
  ),
  3 => 
  array (
    'name' => 'strict_mode4',
    'title' => '控制模式4',
    'type' => 'radio',
    'content' => 
    array (
      1 => '开启',
      0 => '关闭',
    ),
    'value' => '0',
    'rule' => '',
    'msg' => '',
    'tip' => '开启后只有指定UA可以显示真实页面，搜索引擎来路的客户访问跳转广告链接，其他访问者将返回503状态码',
    'ok' => '',
    'extend' => '',
  ),
  4 => 
  array (
    'name' => 'strict_mode5',
    'title' => '控制模式5',
    'type' => 'radio',
    'content' => 
    array (
      1 => '开启',
      0 => '关闭',
    ),
    'value' => '0',
    'rule' => '',
    'msg' => '',
    'tip' => '开启后只有指定IP前两段可以显示真实页面，搜索引擎来路的客户访问跳转广告链接，其他访问者将返回503状态码',
    'ok' => '',
    'extend' => '',
  ),
  5 => 
  array (
    'name' => 'strict_mode6',
    'title' => '控制模式6',
    'type' => 'radio',
    'content' => 
    array (
      1 => '开启',
      0 => '关闭',
    ),
    'value' => '0',
    'rule' => '',
    'msg' => '',
    'tip' => '开启后只有指定UA可以显示真实页面，搜索引擎来路的手机端访客跳转广告链接，其他访问者将返回503状态码',
    'ok' => '',
    'extend' => '',
  ),
  6 => 
  array (
    'name' => 'strict_mode7',
    'title' => '控制模式7',
    'type' => 'radio',
    'content' => 
    array (
      1 => '开启',
      0 => '关闭',
    ),
    'value' => '0',
    'rule' => '',
    'msg' => '',
    'tip' => '开启后只有指定IP前两段可以显示真实页面，搜索引擎来路的手机端访客跳转广告链接，其他访问者将返回503状态码',
    'ok' => '',
    'extend' => '',
  ),
  7 => 
  array (
    'name' => 'strict_mode8',
    'title' => '控制模式8',
    'type' => 'radio',
    'content' => 
    array (
      1 => '开启',
      0 => '关闭',
    ),
    'value' => '0',
    'rule' => '',
    'msg' => '',
    'tip' => '开启后只有指定UA可以显示真实页面，搜索引擎来路的手机端访客跳转广告链接，其他访问者将返回404状态码并显示自定义提示页面',
    'ok' => '',
    'extend' => '',
  ),
  8 => 
  array (
    'name' => 'strict_mode9',
    'title' => '控制模式9',
    'type' => 'radio',
    'content' => 
    array (
      1 => '开启',
      0 => '关闭',
    ),
    'value' => '0',
    'rule' => '',
    'msg' => '',
    'tip' => '开启后只有指定IP前两段可以显示真实页面，搜索引擎来路的手机端访客跳转广告链接，其他访问者将返回404状态码并显示自定义提示页面',
    'ok' => '',
    'extend' => '',
  ),
  9 => 
  array (
    'name' => 'redirect_url',
    'title' => '广告跳转链接',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => 'https://baidu.com/',
    'rule' => 'required',
    'msg' => '',
    'tip' => '百度来路访问者将被跳转到此链接，用于控制模式2、3、4、5、6、7、8和9',
    'ok' => '',
    'extend' => 'style="width: 353px;"',
  ),
  10 => 
  array (
    'name' => 'allowed_ua',
    'title' => '允许访问UA',
    'type' => 'text',
    'content' => 
    array (
    ),
    'value' => 'baiduspider
Baiduspider
360
sogou
bing
soso',
    'rule' => '',
    'msg' => '',
    'tip' => '一行一个UA特征，含有该特征的UA才能访问，用于控制模式4、6、8',
    'ok' => '',
    'extend' => 'style="height: 173px; width: 353px;"',
  ),
  11 => 
  array (
    'name' => 'allowed_ips',
    'title' => '允许访问IP前两段',
    'type' => 'text',
    'content' => 
    array (
    ),
    'value' => '221.209
61.180
180.97
180.101
111.206
206.221
123.181
123.125
220.181
218.30
220.181
61.135
220.181
220.196
220.181
221.208
220.181
220.181
104.233
221.209
113.24
220.181
220.181
218.10
194.233
193.42
185.244
180.149
180.76
180.76
158.247
202.97
149.248
149.28
149.28
144.202
139.180
124.166
123.125
123.125
119.63
124.238
116.179
116.179
111.206
111.202
106.120
118.184
123.126
123.183
111.202
106.38
49.7
58.250
218.30
220.181
36.110
207.46
157.55
40.77
13.66
199.30
65.55
65.5
39.71
154.89
180.153
180.163
66.249
203.208
110.249
111.225
220.243
103.82',
    'rule' => '',
    'msg' => '',
    'tip' => '一行一个IP前两段，如"127.0"，用于控制模式5、7、9',
    'ok' => '',
    'extend' => 'style="height: 173px; width: 353px;"',
  ),
  12 => 
  array (
    'name' => 'js',
    'title' => '自定义提示页面',
    'type' => 'text',
    'content' => 
    array (
    ),
    'value' => '<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404</title>
    <style>
        .main{
            width: 600px;
            height:417px;
            margin: 0 auto;
            margin-top: 125px;
        }
        img{
            margin-bottom: 20px;
        }
        p{
            font-size: 14px;
            color: rgb(32, 33, 36);
        }
        span{
            color:rgb(26, 115, 232);
            cursor: pointer;
        }
        span:hover{
            border-bottom: 1px solid rgb(26, 115, 232);
        }
        button{
            float: right;
            margin-top: 60px;
            background-color: #1970e5;
            color: #fff;
            border-width: 0px;
            padding:10px;
            border-radius: 10%;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="main">
        <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABIAQMAAABvIyEEAAAABlBMVEUAAABTU1OoaSf/AAAAAXRSTlMAQObYZgAAAENJREFUeF7tzbEJACEQRNGBLeAasBCza2lLEGx0CxFGG9hBMDDxRy/72O9FMnIFapGylsu1fgoBdkXfUHLrQgdfrlJN1BdYBjQQm3UAAAAASUVORK5CYII=" alt="">
        <p style="font-size:24px;">无法访问此网站</p>
        <p>检查是否有拼写错误。</p>
        <p>如果拼写无误，请<span>尝试运行 Windos 网络诊断</span>。</p>
        <p style="font-size:12px;">DNS_PROBE_FINSHED_NXDOMAIN</p>
        <button>重新加载</button>
    </div>

</body>
</html>',
    'rule' => 'required',
    'msg' => '',
    'tip' => '自定义提示页面内容，用于控制模式8和9返回404状态码时显示',
    'ok' => '',
    'extend' => 'style="height: 273px; width: 353px;"',
  ),
);
